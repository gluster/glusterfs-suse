#include <config.h>
#define _GL_EXECINFO_INLINE _GL_EXTERN_INLINE
#include "execinfo.h"

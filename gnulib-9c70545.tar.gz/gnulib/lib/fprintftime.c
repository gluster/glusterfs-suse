#define FPRINTFTIME 1
#include "strftime.c"

int isdir (const char *path);
